//
//  ContentView.swift
//  Assignment
//
//  Created by Kunal on 03/01/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ContentViewModel()
    @State private var path: [DeviceData] = [] // Navigation path
    @State var searchText = ""

    var body: some View {
        NavigationStack(path: $path) {
            Group {
                if let computers = searchedDevices, !computers.isEmpty {
                    DevicesList(devices: computers) { selectedComputer in
                        viewModel.navigateToDetail(navigateDetail: selectedComputer)
                    }
                    
                } else {
                    ProgressView("Loading...")
                }
            }
           
            .navigationTitle("Devices")
            .navigationDestination(for: DeviceData.self) { computer in
                DetailView(device: computer)
            }
            .onAppear {
                viewModel.fetchAPI()
                viewModel.navigateDetail = nil
            }
            .onChange(of: viewModel.navigateDetail, {
                if let navigate = viewModel.navigateDetail {
                    path.append(navigate)
                } else {
                    print("Not navigating - navigate")
                }
            })
        }
        .searchable(text: $searchText)
    }
    
    var searchedDevices: [DeviceData]? {
        if searchText.isEmpty {
            return  viewModel.data
        } else {
            return viewModel.data?.filter({$0.name.lowercased().contains(searchText.lowercased())})
        }
    }
}
