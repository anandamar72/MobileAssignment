//
//  ApiService.swift
//  Assignment
//
//  Created by Kunal on 10/01/25.
//

import Foundation

class ApiService : NSObject {
    
    private let baseUrl = ""
    private var deviceDataKey = "deviceDataKey"
  
    
    private let sourcesURL = URL(string: "https://api.restful-api.dev/objects")!
    
    func fetchDeviceDetails(completion : @escaping ([DeviceData]) -> ()){
        
        URLSession.shared.dataTask(with: sourcesURL) { (data, urlResponse, error) in
            if let error = error {
                print("Network error: \(error.localizedDescription)")
                print("Data is coming from Local Storgae")
                DispatchQueue.main.async {
                    let data = self.getData()
                    completion(data)
                }
                // Return an empty array on network failure
                return
            }
            
            if let data = data {
                let jsonDecoder = JSONDecoder()
                let empData = try! jsonDecoder.decode([DeviceData].self, from: data)
                if (empData.isEmpty) {
                    DispatchQueue.main.async {
                        completion([])
                    }
                }
                print("Data is coming from API Call")
                DispatchQueue.main.async {
                    completion(empData)
                }
            }
        }.resume()
    }
    
    func getData() -> [DeviceData] {
        if let data = fetchDataFromLocalStorage() {
            print("ContentViewModel - Data from Local Storage ")
            return data
        }
        return []
    }
    
    // Local Storage Data
    
    func saveDataInLocalStorage(data: [DeviceData]) {
        do {
            let data = try JSONEncoder().encode(data)
            UserDefaults.standard.set(data, forKey: deviceDataKey)
        }
        catch {
            print("Error in encoding data")
        }
    }
    
    func fetchDataFromLocalStorage()  -> [DeviceData]? {
        guard let data = UserDefaults.standard.data(forKey: deviceDataKey) else {  return []
        }
        do {
            let data: [DeviceData] = try JSONDecoder().decode([DeviceData].self, from: data)
            return data
        }
        catch {
            print("Error in decoding data")
        }
     return []
    }
}
